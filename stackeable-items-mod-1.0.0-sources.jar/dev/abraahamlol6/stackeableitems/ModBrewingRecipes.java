package dev.abraahamlol6.stackeableitems;

import dev.abraahamlol6.stackeableitems.mixin.BrewingRecipeRegistryAccessor;
import net.minecraft.class_1802;
import net.minecraft.class_1847;

public class ModBrewingRecipes {
    public static void registerRecipes() {
        // Recetas para Nivel 3 (Poción Nivel 2 + Glowstone)
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8966, class_1802.field_8601, ModPotions.SPEED_III);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8993, class_1802.field_8601, ModPotions.STRENGTH_III);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8992, class_1802.field_8601, ModPotions.REGENERATION_III);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8972, class_1802.field_8601, ModPotions.POISON_III);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8976, class_1802.field_8601, ModPotions.SLOWNESS_III);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8998, class_1802.field_8601, ModPotions.LEAPING_III);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8980, class_1802.field_8601, ModPotions.HEALING_III);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8973, class_1802.field_8601, ModPotions.HARMING_III);

        // Recetas para Duración Extendida 12 min (Poción Base + Redstone)
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8968, class_1802.field_8725, ModPotions.LONG_NIGHT_VISION);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8997, class_1802.field_8725, ModPotions.LONG_INVISIBILITY);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8987, class_1802.field_8725, ModPotions.LONG_FIRE_RESISTANCE);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8994, class_1802.field_8725, ModPotions.LONG_WATER_BREATHING);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8975, class_1802.field_8725, ModPotions.LONG_WEAKNESS);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8974, class_1802.field_8725, ModPotions.LONG_SLOW_FALLING);
        
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_9005, class_1802.field_8725, ModPotions.LONG_SPEED_12);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8978, class_1802.field_8725, ModPotions.LONG_STRENGTH_12);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8986, class_1802.field_8725, ModPotions.LONG_REGENERATION_12);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8982, class_1802.field_8725, ModPotions.LONG_POISON_12);
        BrewingRecipeRegistryAccessor.invokeRegisterPotionRecipe(class_1847.field_8979, class_1802.field_8725, ModPotions.LONG_LEAPING_12);
    }
}
