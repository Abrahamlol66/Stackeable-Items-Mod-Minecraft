package dev.abraahamlol6.stackeableitems.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1812.class)
public class PotionItemMixin {
    @Inject(method = "finishUsing", at = @At("RETURN"), cancellable = true)
    private void onFinishUsing(class_1799 stack, class_1937 world, class_1309 user, CallbackInfoReturnable<class_1799> cir) {
        if (user instanceof class_1657 player && !player.method_31549().field_7477) {
            class_1799 result = cir.getReturnValue();
            // Si el resultado es una botella vacía y el stack original todavía tiene items,
            // significa que necesitamos devolver el stack original y poner la botella en el inventario.
            if (result.method_7909() == class_1802.field_8469 && !stack.method_7960()) {
                if (!player.method_31548().method_7394(new class_1799(class_1802.field_8469))) {
                    player.method_7328(new class_1799(class_1802.field_8469), false);
                }
                cir.setReturnValue(stack);
            }
        }
    }
}
