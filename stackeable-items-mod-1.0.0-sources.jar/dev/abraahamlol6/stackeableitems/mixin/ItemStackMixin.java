package dev.abraahamlol6.stackeableitems.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {

    @Inject(method = "getName", at = @At("RETURN"), cancellable = true)
    private void stackableItems$addLevelToName(CallbackInfoReturnable<class_2561> cir) {
        class_1799 self = (class_1799) (Object) this;
        
        // Solo aplicar a pociones
        if (!(self.method_7909() instanceof class_1812)) return;

        List<class_1293> effects = class_1844.method_8067(self);
        if (effects.isEmpty()) return;

        // Obtener el amplificador del primer efecto
        int amplifier = effects.get(0).method_5578();
        
        // Si el nivel es 2 (amplificador 1) o nivel 3 (amplificador 2)
        if (amplifier >= 1) {
            String suffix = "";
            if (amplifier == 1) suffix = " II";
            else if (amplifier == 2) suffix = " III";
            else suffix = " " + (amplifier + 1); // Por si acaso hay niveles superiores

            class_2561 originalName = cir.getReturnValue();
            if (originalName instanceof class_5250 mutable) {
                cir.setReturnValue(mutable.method_27693(suffix));
            } else {
                cir.setReturnValue(class_2561.method_43470(originalName.getString() + suffix));
            }
        }
    }
}
