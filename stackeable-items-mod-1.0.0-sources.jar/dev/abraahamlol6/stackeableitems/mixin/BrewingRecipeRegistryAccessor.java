package dev.abraahamlol6.stackeableitems.mixin;

import net.minecraft.class_1792;
import net.minecraft.class_1842;
import net.minecraft.class_1845;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1845.class)
public interface BrewingRecipeRegistryAccessor {
    @Invoker("registerPotionRecipe")
    static void invokeRegisterPotionRecipe(class_1842 input, class_1792 ingredient, class_1842 output) {
        throw new UnsupportedOperationException();
    }
}
