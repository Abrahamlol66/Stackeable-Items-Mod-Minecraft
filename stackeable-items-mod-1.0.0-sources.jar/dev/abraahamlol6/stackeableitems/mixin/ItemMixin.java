package dev.abraahamlol6.stackeableitems.mixin;

import net.minecraft.class_1792;
import net.minecraft.class_1803;
import net.minecraft.class_1812;
import net.minecraft.class_1828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1792.class)
public abstract class ItemMixin {
    @Inject(method = "getMaxCount", at = @At("HEAD"), cancellable = true)
    private void stackableItems$modifyMaxCount(CallbackInfoReturnable<Integer> cir) {
        if ((Object)this instanceof class_1812 || (Object)this instanceof class_1828 || (Object)this instanceof class_1803) {
            cir.setReturnValue(64);
        }
    }
}
