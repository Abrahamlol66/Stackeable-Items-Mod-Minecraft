package dev.abraahamlol6.stackeableitems.mixin;

import net.minecraft.class_1293;
import net.minecraft.class_1842;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1842.class)
public class PotionDurationMixin {

    @Inject(method = "<init>(Ljava/lang/String;[Lnet/minecraft/entity/effect/StatusEffectInstance;)V", at = @At("HEAD"))
    private static void onInit(String baseName, class_1293[] effects, CallbackInfo ci) {
        for (int i = 0; i < effects.length; i++) {
            class_1293 effect = effects[i];
            int duration = effect.method_5584();
            
            // Si es una poción instantánea, no se suma tiempo.
            if (duration <= 1) continue;

            // Si es Nivel 2 (Amplificador 1), sumar 30 segundos (600 ticks) para que dure 2:00
            if (effect.method_5578() == 1) {
                effects[i] = new class_1293(effect.method_5579(), duration + 600, effect.method_5578(), effect.method_5591(), effect.method_5581(), effect.method_5592());
            }
        }
    }
}
