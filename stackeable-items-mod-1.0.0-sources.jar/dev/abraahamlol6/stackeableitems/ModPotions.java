package dev.abraahamlol6.stackeableitems;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1842;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModPotions {
    // Nivel 3 (Amplificador 2) - Se define con 1:30 (1800 ticks)
    public static final class_1842 SPEED_III = register("speed_iii", new class_1842("speed", new class_1293(class_1294.field_5904, 1800, 2)));
    public static final class_1842 STRENGTH_III = register("strength_iii", new class_1842("strength", new class_1293(class_1294.field_5910, 1800, 2)));
    public static final class_1842 REGENERATION_III = register("regeneration_iii", new class_1842("regeneration", new class_1293(class_1294.field_5924, 1800, 2)));
    public static final class_1842 POISON_III = register("poison_iii", new class_1842("poison", new class_1293(class_1294.field_5899, 1800, 2)));
    public static final class_1842 SLOWNESS_III = register("slowness_iii", new class_1842("slowness", new class_1293(class_1294.field_5909, 1800, 2)));
    public static final class_1842 LEAPING_III = register("leaping_iii", new class_1842("jump_boost", new class_1293(class_1294.field_5913, 1800, 2)));
    public static final class_1842 HEALING_III = register("healing_iii", new class_1842("healing", new class_1293(class_1294.field_5915, 1, 2)));
    public static final class_1842 HARMING_III = register("harming_iii", new class_1842("harming", new class_1293(class_1294.field_5921, 1, 2)));

    // Duración Extendida - Usando duración Long Vanilla (8:00 = 9600 ticks)
    public static final class_1842 LONG_NIGHT_VISION = register("long_night_vision_12", new class_1842("night_vision", new class_1293(class_1294.field_5925, 9600)));
    public static final class_1842 LONG_INVISIBILITY = register("long_invisibility_12", new class_1842("invisibility", new class_1293(class_1294.field_5905, 9600)));
    public static final class_1842 LONG_FIRE_RESISTANCE = register("long_fire_resistance_12", new class_1842("fire_resistance", new class_1293(class_1294.field_5918, 9600)));
    public static final class_1842 LONG_WATER_BREATHING = register("long_water_breathing_12", new class_1842("water_breathing", new class_1293(class_1294.field_5923, 9600)));
    public static final class_1842 LONG_WEAKNESS = register("long_weakness_12", new class_1842("weakness", new class_1293(class_1294.field_5911, 9600)));
    public static final class_1842 LONG_SLOW_FALLING = register("long_slow_falling_12", new class_1842("slow_falling", new class_1293(class_1294.field_5906, 9600)));
    
    // Versiones Extendidas de niveles 1 (8:00 Vanilla)
    public static final class_1842 LONG_SPEED_12 = register("long_speed_12", new class_1842("speed", new class_1293(class_1294.field_5904, 9600)));
    public static final class_1842 LONG_STRENGTH_12 = register("long_strength_12", new class_1842("strength", new class_1293(class_1294.field_5910, 9600)));
    public static final class_1842 LONG_REGENERATION_12 = register("long_regeneration_12", new class_1842("regeneration", new class_1293(class_1294.field_5924, 9600)));
    public static final class_1842 LONG_POISON_12 = register("long_poison_12", new class_1842("poison", new class_1293(class_1294.field_5899, 9600)));
    public static final class_1842 LONG_LEAPING_12 = register("long_leaping_12", new class_1842("jump_boost", new class_1293(class_1294.field_5913, 9600)));

    private static class_1842 register(String name, class_1842 potion) {
        return class_2378.method_10230(class_7923.field_41179, new class_2960(StackeableItemsMod.MOD_ID, name), potion);
    }

    public static void registerPotions() {
        StackeableItemsMod.LOGGER.info("Registering custom potions for " + StackeableItemsMod.MOD_ID);
    }
}
